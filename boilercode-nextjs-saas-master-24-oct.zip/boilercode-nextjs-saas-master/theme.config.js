export default {
  logo: <span>BoilerCode.co Documentation</span>,
  project: {
    link: "https://boilercode.co",
  },
  feedback: false,
  editLink: false,
  // ... other theme options
};
