import {
    MdOutlineRssFeed,
    MdRocketLaunch,
    MdOutlineShield,
    MdPublishedWithChanges,
    MdSpeed,
  } from "react-icons/md";
  import { BsGlobeAmericas } from "react-icons/bs";
  import { TbSeo } from "react-icons/tb";
  import { BiDollar } from "react-icons/bi";

const features = [
  {
    Icon: MdOutlineRssFeed,
    title: "Feature 1",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: MdRocketLaunch,
    title: "Feature 2",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: BsGlobeAmericas,
    title: "Feature 3",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: MdOutlineShield,
    title: "Feature 4",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: MdPublishedWithChanges,
    title: "Feature 5",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: MdSpeed,
    title: "Feature 6",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: TbSeo,
    title: "Feature 7",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
  {
    Icon: BiDollar,
    title: "Feature 8",
    description:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.",
  },
];

export default features;
